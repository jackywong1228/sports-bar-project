-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: sports_bar
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.22.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity`
--

DROP TABLE IF EXISTS `activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '活动标题',
  `cover_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '封面图片',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '活动描述',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '活动详情',
  `start_time` datetime NOT NULL COMMENT '开始时间',
  `end_time` datetime NOT NULL COMMENT '结束时间',
  `registration_deadline` datetime DEFAULT NULL COMMENT '报名截止时间',
  `location` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '活动地点',
  `venue_id` int DEFAULT NULL COMMENT '关联场地ID',
  `max_participants` int DEFAULT NULL COMMENT '最大参与人数，0表示不限',
  `current_participants` int DEFAULT NULL COMMENT '当前报名人数',
  `price` decimal(10,2) DEFAULT NULL COMMENT '报名费用（金币）',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态',
  `tags` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标签，逗号分隔',
  `sort_order` int DEFAULT NULL COMMENT '排序',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity`
--

LOCK TABLES `activity` WRITE;
/*!40000 ALTER TABLE `activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activity_registration`
--

DROP TABLE IF EXISTS `activity_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_registration` (
  `id` int NOT NULL AUTO_INCREMENT,
  `activity_id` int NOT NULL COMMENT '活动ID',
  `member_id` int NOT NULL COMMENT '会员ID',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '报名姓名',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系电话',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '支付金额',
  `pay_time` datetime DEFAULT NULL COMMENT '支付时间',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态：registered/cancelled/attended',
  `check_in_time` datetime DEFAULT NULL COMMENT '签到时间',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_registration`
--

LOCK TABLES `activity_registration` WRITE;
/*!40000 ALTER TABLE `activity_registration` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcement`
--

DROP TABLE IF EXISTS `announcement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcement` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '公告标题',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '公告内容',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '类型：normal/important/urgent',
  `target` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '目标：all/member/coach',
  `is_top` tinyint(1) DEFAULT NULL COMMENT '是否置顶',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态：draft/published/offline',
  `publish_time` datetime DEFAULT NULL COMMENT '发布时间',
  `start_time` datetime DEFAULT NULL COMMENT '生效开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '生效结束时间',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement`
--

LOCK TABLES `announcement` WRITE;
/*!40000 ALTER TABLE `announcement` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banner`
--

DROP TABLE IF EXISTS `banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `banner` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标题',
  `image` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图片URL',
  `link_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '跳转类型：none/page/activity/url',
  `link_value` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '跳转值',
  `position` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '显示位置：home/activity/mall',
  `sort_order` int DEFAULT NULL COMMENT '排序',
  `is_active` tinyint(1) DEFAULT NULL COMMENT '是否启用',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banner`
--

LOCK TABLES `banner` WRITE;
/*!40000 ALTER TABLE `banner` DISABLE KEYS */;
/*!40000 ALTER TABLE `banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coach`
--

DROP TABLE IF EXISTS `coach`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coach` (
  `id` int NOT NULL AUTO_INCREMENT,
  `member_id` int DEFAULT NULL COMMENT '关联会员ID',
  `coach_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '教练编号',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '教练姓名',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '联系电话',
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '头像',
  `gender` int DEFAULT NULL COMMENT '性别: 0未知 1男 2女',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '教练类型: technical技术 entertainment娱乐',
  `level` int DEFAULT NULL COMMENT '教练星级 1-5',
  `price` decimal(10,2) DEFAULT NULL COMMENT '课时单价(金币)',
  `introduction` text COLLATE utf8mb4_unicode_ci COMMENT '教练介绍',
  `skills` text COLLATE utf8mb4_unicode_ci COMMENT '技能标签(JSON)',
  `certificates` text COLLATE utf8mb4_unicode_ci COMMENT '资质证书(JSON)',
  `photos` text COLLATE utf8mb4_unicode_ci COMMENT '教练照片(JSON)',
  `status` int DEFAULT NULL COMMENT '状态: 0离职 1在职 2休假',
  `total_courses` int DEFAULT NULL COMMENT '累计课程数',
  `total_income` decimal(10,2) DEFAULT NULL COMMENT '累计收入',
  `coin_balance` decimal(10,2) DEFAULT NULL COMMENT '金币余额',
  `point_balance` int DEFAULT NULL COMMENT '积分余额',
  `pending_income` decimal(10,2) DEFAULT NULL COMMENT '待结算收入',
  `invite_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邀请码',
  `tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标签(逗号分隔)',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `coach_no` (`coach_no`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `coach_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coach`
--

LOCK TABLES `coach` WRITE;
/*!40000 ALTER TABLE `coach` DISABLE KEYS */;
/*!40000 ALTER TABLE `coach` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coach_application`
--

DROP TABLE IF EXISTS `coach_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coach_application` (
  `id` int NOT NULL AUTO_INCREMENT,
  `member_id` int NOT NULL COMMENT '申请人会员ID',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '姓名',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '联系电话',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '申请类型: technical技术 entertainment娱乐',
  `introduction` text COLLATE utf8mb4_unicode_ci COMMENT '个人介绍',
  `skills` text COLLATE utf8mb4_unicode_ci COMMENT '技能特长(JSON)',
  `certificates` text COLLATE utf8mb4_unicode_ci COMMENT '资质证书(JSON)',
  `status` int DEFAULT NULL COMMENT '状态: 0待审核 1通过 2拒绝',
  `audit_time` datetime DEFAULT NULL COMMENT '审核时间',
  `audit_user_id` int DEFAULT NULL COMMENT '审核人ID',
  `audit_remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审核备注',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `coach_application_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coach_application`
--

LOCK TABLES `coach_application` WRITE;
/*!40000 ALTER TABLE `coach_application` DISABLE KEYS */;
/*!40000 ALTER TABLE `coach_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coach_schedule`
--

DROP TABLE IF EXISTS `coach_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coach_schedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `coach_id` int NOT NULL COMMENT '教练ID',
  `date` date NOT NULL COMMENT '日期',
  `time_slot` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '时间段 HH:MM',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态: available可用 unavailable不可用 reserved已预约',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `coach_id` (`coach_id`),
  CONSTRAINT `coach_schedule_ibfk_1` FOREIGN KEY (`coach_id`) REFERENCES `coach` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coach_schedule`
--

LOCK TABLES `coach_schedule` WRITE;
/*!40000 ALTER TABLE `coach_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `coach_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coach_settlement`
--

DROP TABLE IF EXISTS `coach_settlement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coach_settlement` (
  `id` int NOT NULL AUTO_INCREMENT,
  `settlement_no` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '结算单号',
  `coach_id` int NOT NULL COMMENT '教练ID',
  `period_start` date NOT NULL COMMENT '结算开始日期',
  `period_end` date NOT NULL COMMENT '结算结束日期',
  `total_lessons` int DEFAULT NULL COMMENT '总课时数',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '总金额',
  `platform_fee` decimal(10,2) DEFAULT NULL COMMENT '平台服务费',
  `settlement_amount` decimal(10,2) DEFAULT NULL COMMENT '结算金额',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态：pending/confirmed/paid',
  `pay_time` datetime DEFAULT NULL COMMENT '支付时间',
  `pay_account` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收款账户',
  `pay_remark` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付备注',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `settlement_no` (`settlement_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coach_settlement`
--

LOCK TABLES `coach_settlement` WRITE;
/*!40000 ALTER TABLE `coach_settlement` DISABLE KEYS */;
/*!40000 ALTER TABLE `coach_settlement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin_record`
--

DROP TABLE IF EXISTS `coin_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coin_record` (
  `id` int NOT NULL AUTO_INCREMENT,
  `member_id` int NOT NULL COMMENT '会员ID',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '类型: income/expense',
  `amount` decimal(10,2) NOT NULL COMMENT '金额',
  `balance` decimal(10,2) NOT NULL COMMENT '变动后余额',
  `source` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '来源',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `operator_id` int DEFAULT NULL COMMENT '操作人ID',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `coin_record_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin_record`
--

LOCK TABLES `coin_record` WRITE;
/*!40000 ALTER TABLE `coin_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consume_record`
--

DROP TABLE IF EXISTS `consume_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consume_record` (
  `id` int NOT NULL AUTO_INCREMENT,
  `member_id` int NOT NULL COMMENT '会员ID',
  `consume_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '类型：venue/coach/food/activity/mall',
  `order_id` int DEFAULT NULL COMMENT '关联订单ID',
  `order_no` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '关联订单号',
  `amount` decimal(10,2) NOT NULL COMMENT '消费金额（金币）',
  `title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '消费描述',
  `coupon_id` int DEFAULT NULL COMMENT '使用的优惠券ID',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '优惠金额',
  `actual_amount` decimal(10,2) DEFAULT NULL COMMENT '实际支付金额',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consume_record`
--

LOCK TABLES `consume_record` WRITE;
/*!40000 ALTER TABLE `consume_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `consume_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon_template`
--

DROP TABLE IF EXISTS `coupon_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupon_template` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '券名称',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '类型：discount/cash/gift',
  `discount_value` decimal(10,2) DEFAULT NULL COMMENT '优惠值（折扣率或金额）',
  `min_amount` decimal(10,2) DEFAULT NULL COMMENT '最低消费金额',
  `max_discount` decimal(10,2) DEFAULT NULL COMMENT '最大优惠金额',
  `applicable_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '适用类型：all/venue/food/coach',
  `applicable_ids` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '适用ID列表，逗号分隔',
  `valid_days` int DEFAULT NULL COMMENT '有效天数（领取后）',
  `start_time` datetime DEFAULT NULL COMMENT '固定开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '固定结束时间',
  `total_count` int DEFAULT NULL COMMENT '发放总量，0表示不限',
  `issued_count` int DEFAULT NULL COMMENT '已发放数量',
  `per_limit` int DEFAULT NULL COMMENT '每人限领',
  `is_active` tinyint(1) DEFAULT NULL COMMENT '是否启用',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '使用说明',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_template`
--

LOCK TABLES `coupon_template` WRITE;
/*!40000 ALTER TABLE `coupon_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `finance_stat`
--

DROP TABLE IF EXISTS `finance_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `finance_stat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `stat_date` date NOT NULL COMMENT '统计日期',
  `recharge_amount` decimal(12,2) DEFAULT NULL COMMENT '充值金额',
  `recharge_count` int DEFAULT NULL COMMENT '充值笔数',
  `venue_consume` decimal(12,2) DEFAULT NULL COMMENT '场馆消费',
  `coach_consume` decimal(12,2) DEFAULT NULL COMMENT '教练消费',
  `food_consume` decimal(12,2) DEFAULT NULL COMMENT '餐饮消费',
  `activity_consume` decimal(12,2) DEFAULT NULL COMMENT '活动消费',
  `mall_consume` decimal(12,2) DEFAULT NULL COMMENT '商城消费',
  `total_consume` decimal(12,2) DEFAULT NULL COMMENT '总消费',
  `refund_amount` decimal(12,2) DEFAULT NULL COMMENT '退款金额',
  `refund_count` int DEFAULT NULL COMMENT '退款笔数',
  `coach_settlement` decimal(12,2) DEFAULT NULL COMMENT '教练结算金额',
  `new_members` int DEFAULT NULL COMMENT '新增会员数',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `stat_date` (`stat_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `finance_stat`
--

LOCK TABLES `finance_stat` WRITE;
/*!40000 ALTER TABLE `finance_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `finance_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food_category`
--

DROP TABLE IF EXISTS `food_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `food_category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '分类名称',
  `icon` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分类图标',
  `sort_order` int DEFAULT NULL COMMENT '排序',
  `is_active` tinyint(1) DEFAULT NULL COMMENT '是否启用',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food_category`
--

LOCK TABLES `food_category` WRITE;
/*!40000 ALTER TABLE `food_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `food_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food_item`
--

DROP TABLE IF EXISTS `food_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `food_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_id` int NOT NULL COMMENT '分类ID',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '商品名称',
  `image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品图片',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '商品描述',
  `price` decimal(10,2) NOT NULL COMMENT '价格（金币）',
  `original_price` decimal(10,2) DEFAULT NULL COMMENT '原价',
  `stock` int DEFAULT NULL COMMENT '库存',
  `sales` int DEFAULT NULL COMMENT '销量',
  `is_active` tinyint(1) DEFAULT NULL COMMENT '是否上架',
  `is_recommend` tinyint(1) DEFAULT NULL COMMENT '是否推荐',
  `tags` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标签，逗号分隔',
  `sort_order` int DEFAULT NULL COMMENT '排序',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food_item`
--

LOCK TABLES `food_item` WRITE;
/*!40000 ALTER TABLE `food_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `food_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food_order`
--

DROP TABLE IF EXISTS `food_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `food_order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_no` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '订单号',
  `member_id` int NOT NULL COMMENT '会员ID',
  `total_amount` decimal(10,2) NOT NULL COMMENT '总金额',
  `pay_amount` decimal(10,2) NOT NULL COMMENT '实付金额',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态：pending/paid/preparing/ready/completed/cancelled',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `table_no` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '桌号',
  `order_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单类型：immediate立即取餐/scheduled预约取餐',
  `scheduled_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '预约取餐时间，格式：HH:MM',
  `scheduled_date` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '预约取餐日期，格式：YYYY-MM-DD',
  `pay_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付时间',
  `complete_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '完成时间',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food_order`
--

LOCK TABLES `food_order` WRITE;
/*!40000 ALTER TABLE `food_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `food_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food_order_item`
--

DROP TABLE IF EXISTS `food_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `food_order_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL COMMENT '订单ID',
  `food_id` int NOT NULL COMMENT '商品ID',
  `food_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品名称',
  `food_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品图片',
  `price` decimal(10,2) NOT NULL COMMENT '单价',
  `quantity` int DEFAULT NULL COMMENT '数量',
  `subtotal` decimal(10,2) NOT NULL COMMENT '小计',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food_order_item`
--

LOCK TABLES `food_order_item` WRITE;
/*!40000 ALTER TABLE `food_order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `food_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `id` int NOT NULL AUTO_INCREMENT,
  `openid` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '微信OpenID',
  `unionid` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '微信UnionID',
  `session_key` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '微信会话密钥',
  `nickname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '昵称',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '头像',
  `real_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '真实姓名',
  `gender` int DEFAULT NULL COMMENT '性别: 0未知 1男 2女',
  `birthday` datetime DEFAULT NULL COMMENT '生日',
  `level_id` int DEFAULT NULL COMMENT '会员等级ID',
  `member_expire_time` datetime DEFAULT NULL COMMENT '会员到期时间',
  `coin_balance` decimal(10,2) DEFAULT NULL COMMENT '金币余额',
  `point_balance` int DEFAULT NULL COMMENT '积分余额',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `openid` (`openid`),
  KEY `level_id` (`level_id`),
  CONSTRAINT `member_ibfk_1` FOREIGN KEY (`level_id`) REFERENCES `member_level` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_card`
--

DROP TABLE IF EXISTS `member_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_card` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '套餐名称',
  `level_id` int NOT NULL COMMENT '会员等级ID',
  `original_price` decimal(10,2) NOT NULL COMMENT '原价',
  `price` decimal(10,2) NOT NULL COMMENT '售价',
  `duration_days` int NOT NULL COMMENT '有效天数',
  `bonus_coins` decimal(10,2) DEFAULT NULL COMMENT '赠送金币',
  `bonus_points` int DEFAULT NULL COMMENT '赠送积分',
  `cover_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '封面图',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '套餐描述',
  `highlights` text COLLATE utf8mb4_unicode_ci COMMENT '套餐亮点，JSON数组',
  `sort_order` int DEFAULT NULL COMMENT '排序',
  `is_recommended` tinyint(1) DEFAULT NULL COMMENT '是否推荐',
  `is_active` tinyint(1) DEFAULT NULL COMMENT '是否上架',
  `sales_count` int DEFAULT NULL COMMENT '销量',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  KEY `level_id` (`level_id`),
  CONSTRAINT `member_card_ibfk_1` FOREIGN KEY (`level_id`) REFERENCES `member_level` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_card`
--

LOCK TABLES `member_card` WRITE;
/*!40000 ALTER TABLE `member_card` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_card_order`
--

DROP TABLE IF EXISTS `member_card_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_card_order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '订单号',
  `member_id` int NOT NULL COMMENT '会员ID',
  `card_id` int NOT NULL COMMENT '会员卡套餐ID',
  `original_price` decimal(10,2) NOT NULL COMMENT '原价',
  `pay_amount` decimal(10,2) NOT NULL COMMENT '实付金额',
  `bonus_coins` decimal(10,2) DEFAULT NULL COMMENT '赠送金币',
  `bonus_points` int DEFAULT NULL COMMENT '赠送积分',
  `level_id` int DEFAULT NULL COMMENT '开通的会员等级ID',
  `duration_days` int DEFAULT NULL COMMENT '有效天数',
  `start_time` datetime DEFAULT NULL COMMENT '会员开始时间',
  `expire_time` datetime DEFAULT NULL COMMENT '会员到期时间',
  `pay_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付方式: coin/wechat',
  `pay_time` datetime DEFAULT NULL COMMENT '支付时间',
  `transaction_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '微信支付交易号',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态: pending/paid/cancelled/refunded',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`),
  KEY `member_id` (`member_id`),
  KEY `card_id` (`card_id`),
  CONSTRAINT `member_card_order_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`),
  CONSTRAINT `member_card_order_ibfk_2` FOREIGN KEY (`card_id`) REFERENCES `member_card` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_card_order`
--

LOCK TABLES `member_card_order` WRITE;
/*!40000 ALTER TABLE `member_card_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_card_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_coupon`
--

DROP TABLE IF EXISTS `member_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_coupon` (
  `id` int NOT NULL AUTO_INCREMENT,
  `template_id` int NOT NULL COMMENT '模板ID',
  `member_id` int NOT NULL COMMENT '会员ID',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '券名称',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '类型',
  `discount_value` decimal(10,2) DEFAULT NULL COMMENT '优惠值',
  `min_amount` decimal(10,2) DEFAULT NULL COMMENT '最低消费',
  `start_time` datetime DEFAULT NULL COMMENT '生效时间',
  `end_time` datetime DEFAULT NULL COMMENT '失效时间',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态：unused/used/expired',
  `use_time` datetime DEFAULT NULL COMMENT '使用时间',
  `order_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单类型',
  `order_id` int DEFAULT NULL COMMENT '订单ID',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_coupon`
--

LOCK TABLES `member_coupon` WRITE;
/*!40000 ALTER TABLE `member_coupon` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_level`
--

DROP TABLE IF EXISTS `member_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_level` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '等级名称',
  `level` int NOT NULL COMMENT '等级值',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '等级类型: normal/fitness/ball/vip',
  `discount` decimal(3,2) DEFAULT NULL COMMENT '折扣率',
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '等级图标',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '等级描述',
  `venue_permissions` text COLLATE utf8mb4_unicode_ci COMMENT '场馆权限，JSON格式',
  `benefits` text COLLATE utf8mb4_unicode_ci COMMENT '会员权益说明',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_level`
--

LOCK TABLES `member_level` WRITE;
/*!40000 ALTER TABLE `member_level` DISABLE KEYS */;
INSERT INTO `member_level` VALUES (1,'普通会员',1,'normal',1.00,NULL,NULL,NULL,NULL,1,'2026-01-18 14:39:53','2026-01-18 14:39:53'),(2,'银卡会员',2,'normal',0.95,NULL,NULL,NULL,NULL,1,'2026-01-18 14:39:53','2026-01-18 14:39:53'),(3,'金卡会员',3,'normal',0.90,NULL,NULL,NULL,NULL,1,'2026-01-18 14:39:53','2026-01-18 14:39:53'),(4,'钻石会员',4,'normal',0.85,NULL,NULL,NULL,NULL,1,'2026-01-18 14:39:53','2026-01-18 14:39:53'),(5,'黑金会员',5,'normal',0.80,NULL,NULL,NULL,NULL,1,'2026-01-18 14:39:53','2026-01-18 14:39:53');
/*!40000 ALTER TABLE `member_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_tag`
--

DROP TABLE IF EXISTS `member_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_tag` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标签名称',
  `color` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标签颜色',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_tag`
--

LOCK TABLES `member_tag` WRITE;
/*!40000 ALTER TABLE `member_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_tag_relation`
--

DROP TABLE IF EXISTS `member_tag_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_tag_relation` (
  `member_id` int NOT NULL,
  `tag_id` int NOT NULL,
  PRIMARY KEY (`member_id`,`tag_id`),
  KEY `tag_id` (`tag_id`),
  CONSTRAINT `member_tag_relation_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`),
  CONSTRAINT `member_tag_relation_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `member_tag` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_tag_relation`
--

LOCK TABLES `member_tag_relation` WRITE;
/*!40000 ALTER TABLE `member_tag_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_tag_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message` (
  `id` int NOT NULL AUTO_INCREMENT,
  `receiver_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '接收者类型：member/coach/all',
  `receiver_id` int DEFAULT NULL COMMENT '接收者ID，all时为空',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '类型：system/activity/order/reservation',
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '消息标题',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '消息内容',
  `biz_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '业务类型',
  `biz_id` int DEFAULT NULL COMMENT '业务ID',
  `is_read` tinyint(1) DEFAULT NULL COMMENT '是否已读',
  `read_time` datetime DEFAULT NULL COMMENT '阅读时间',
  `push_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '推送状态：pending/sent/failed',
  `push_time` datetime DEFAULT NULL COMMENT '推送时间',
  `push_result` text COLLATE utf8mb4_unicode_ci COMMENT '推送结果',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_template`
--

DROP TABLE IF EXISTS `message_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_template` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板编码',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板名称',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '类型：system/activity/order/reservation',
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '消息标题',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '消息内容模板',
  `variables` text COLLATE utf8mb4_unicode_ci COMMENT '变量说明，JSON格式',
  `push_wechat` tinyint(1) DEFAULT NULL COMMENT '是否推送微信订阅消息',
  `wechat_template_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '微信订阅消息模板ID',
  `is_active` tinyint(1) DEFAULT NULL COMMENT '是否启用',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_template`
--

LOCK TABLES `message_template` WRITE;
/*!40000 ALTER TABLE `message_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `point_record`
--

DROP TABLE IF EXISTS `point_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `point_record` (
  `id` int NOT NULL AUTO_INCREMENT,
  `member_id` int NOT NULL COMMENT '会员ID',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '类型: income/expense',
  `amount` int NOT NULL COMMENT '数量',
  `balance` int NOT NULL COMMENT '变动后余额',
  `source` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '来源',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `operator_id` int DEFAULT NULL COMMENT '操作人ID',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `point_record_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `point_record`
--

LOCK TABLES `point_record` WRITE;
/*!40000 ALTER TABLE `point_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `point_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_id` int NOT NULL COMMENT '分类ID',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '商品名称',
  `image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品主图',
  `images` text COLLATE utf8mb4_unicode_ci COMMENT '商品图片列表，JSON格式',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '商品描述',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '商品详情',
  `points` int NOT NULL COMMENT '所需积分',
  `price` decimal(10,2) DEFAULT NULL COMMENT '额外金币价格',
  `market_price` decimal(10,2) DEFAULT NULL COMMENT '市场价',
  `stock` int DEFAULT NULL COMMENT '库存',
  `sales` int DEFAULT NULL COMMENT '兑换量',
  `is_active` tinyint(1) DEFAULT NULL COMMENT '是否上架',
  `is_recommend` tinyint(1) DEFAULT NULL COMMENT '是否推荐',
  `tags` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标签，逗号分隔',
  `sort_order` int DEFAULT NULL COMMENT '排序',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_category`
--

DROP TABLE IF EXISTS `product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '分类名称',
  `icon` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分类图标',
  `sort_order` int DEFAULT NULL COMMENT '排序',
  `is_active` tinyint(1) DEFAULT NULL COMMENT '是否启用',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_category`
--

LOCK TABLES `product_category` WRITE;
/*!40000 ALTER TABLE `product_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_order`
--

DROP TABLE IF EXISTS `product_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_no` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '订单号',
  `member_id` int NOT NULL COMMENT '会员ID',
  `product_id` int NOT NULL COMMENT '商品ID',
  `product_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品名称',
  `product_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品图片',
  `quantity` int DEFAULT NULL COMMENT '兑换数量',
  `points_used` int DEFAULT NULL COMMENT '消耗积分',
  `coins_used` decimal(10,2) DEFAULT NULL COMMENT '消耗金币',
  `receiver_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收货人电话',
  `receiver_address` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收货地址',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态：pending/shipped/completed/cancelled',
  `express_company` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '快递公司',
  `express_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '快递单号',
  `ship_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '发货时间',
  `complete_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '完成时间',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_order`
--

LOCK TABLES `product_order` WRITE;
/*!40000 ALTER TABLE `product_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recharge_order`
--

DROP TABLE IF EXISTS `recharge_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recharge_order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_no` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '订单号',
  `member_id` int NOT NULL COMMENT '会员ID',
  `amount` decimal(10,2) NOT NULL COMMENT '充值金额（元）',
  `coins` int NOT NULL COMMENT '获得金币',
  `bonus_coins` int DEFAULT NULL COMMENT '赠送金币',
  `pay_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付方式：wechat/alipay',
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '微信支付交易号',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态：pending/paid/failed/refunded',
  `pay_time` datetime DEFAULT NULL COMMENT '支付时间',
  `expire_time` datetime DEFAULT NULL COMMENT '过期时间',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recharge_order`
--

LOCK TABLES `recharge_order` WRITE;
/*!40000 ALTER TABLE `recharge_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `recharge_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reservation_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '预约编号',
  `member_id` int NOT NULL COMMENT '会员ID',
  `venue_id` int NOT NULL COMMENT '场馆ID',
  `coach_id` int DEFAULT NULL COMMENT '教练ID',
  `reservation_date` date NOT NULL COMMENT '预约日期',
  `start_time` time NOT NULL COMMENT '开始时间',
  `end_time` time NOT NULL COMMENT '结束时间',
  `duration` int NOT NULL COMMENT '时长(分钟)',
  `venue_price` decimal(10,2) DEFAULT NULL COMMENT '场馆费用(金币)',
  `coach_price` decimal(10,2) DEFAULT NULL COMMENT '教练费用(金币)',
  `total_price` decimal(10,2) DEFAULT NULL COMMENT '总费用(金币)',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '预约状态',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '类型: normal普通 activity活动',
  `is_settled` tinyint(1) DEFAULT NULL COMMENT '是否已结算',
  `settled_at` datetime DEFAULT NULL COMMENT '结算时间',
  `rating` int DEFAULT NULL COMMENT '评分 1-5',
  `comment` text COLLATE utf8mb4_unicode_ci COMMENT '评价内容',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `cancel_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '取消原因',
  `cancel_time` datetime DEFAULT NULL COMMENT '取消时间',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `reservation_no` (`reservation_no`),
  KEY `member_id` (`member_id`),
  KEY `venue_id` (`venue_id`),
  KEY `coach_id` (`coach_id`),
  CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`),
  CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`venue_id`) REFERENCES `venue` (`id`),
  CONSTRAINT `reservation_ibfk_3` FOREIGN KEY (`coach_id`) REFERENCES `coach` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_department`
--

DROP TABLE IF EXISTS `sys_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_department` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '部门名称',
  `parent_id` int DEFAULT NULL COMMENT '上级部门ID',
  `sort` int DEFAULT NULL COMMENT '排序',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `sys_department_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `sys_department` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_department`
--

LOCK TABLES `sys_department` WRITE;
/*!40000 ALTER TABLE `sys_department` DISABLE KEYS */;
INSERT INTO `sys_department` VALUES (1,'总部',NULL,1,1,NULL,'2026-01-18 14:37:19','2026-01-18 14:37:19',0,NULL);
/*!40000 ALTER TABLE `sys_department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_permission`
--

DROP TABLE IF EXISTS `sys_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '权限名称',
  `code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '权限编码',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '权限类型: menu/button',
  `parent_id` int DEFAULT NULL COMMENT '上级权限ID',
  `path` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '路由路径',
  `component` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '组件路径',
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '图标',
  `sort` int DEFAULT NULL COMMENT '排序',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `sys_permission_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `sys_permission` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_permission`
--

LOCK TABLES `sys_permission` WRITE;
/*!40000 ALTER TABLE `sys_permission` DISABLE KEYS */;
INSERT INTO `sys_permission` VALUES (1,'系统管理','system','menu',NULL,'/system',NULL,'Setting',1,1,'2026-01-18 14:37:19','2026-01-18 14:37:19'),(2,'会员管理','member','menu',NULL,'/member',NULL,'User',2,1,'2026-01-18 14:37:19','2026-01-18 14:37:19'),(3,'场地管理','venue','menu',NULL,'/venue',NULL,'Location',3,1,'2026-01-18 14:37:19','2026-01-18 14:37:19'),(4,'预约管理','reservation','menu',NULL,'/reservation',NULL,'Calendar',4,1,'2026-01-18 14:37:19','2026-01-18 14:37:19'),(5,'教练管理','coach','menu',NULL,'/coach',NULL,'Avatar',5,1,'2026-01-18 14:37:19','2026-01-18 14:37:19'),(6,'用户管理','system:user','menu',1,'/system/user',NULL,NULL,1,1,'2026-01-18 14:37:19','2026-01-18 14:37:19'),(7,'角色管理','system:role','menu',1,'/system/role',NULL,NULL,2,1,'2026-01-18 14:37:19','2026-01-18 14:37:19'),(8,'部门管理','system:department','menu',1,'/system/department',NULL,NULL,3,1,'2026-01-18 14:37:19','2026-01-18 14:37:19'),(9,'权限管理','system:permission','menu',1,'/system/permission',NULL,NULL,4,1,'2026-01-18 14:37:19','2026-01-18 14:37:19'),(10,'会员列表','member:list','menu',2,'/member/list',NULL,NULL,1,1,'2026-01-18 14:37:19','2026-01-18 14:37:19'),(11,'会员等级','member:level','menu',2,'/member/level',NULL,NULL,2,1,'2026-01-18 14:37:19','2026-01-18 14:37:19'),(12,'会员标签','member:tag','menu',2,'/member/tag',NULL,NULL,3,1,'2026-01-18 14:37:19','2026-01-18 14:37:19'),(13,'场地列表','venue:list','menu',3,'/venue/list',NULL,NULL,1,1,'2026-01-18 14:37:19','2026-01-18 14:37:19'),(14,'场地类型','venue:type','menu',3,'/venue/type',NULL,NULL,2,1,'2026-01-18 14:37:19','2026-01-18 14:37:19'),(15,'预约记录','reservation:list','menu',4,'/reservation/list',NULL,NULL,1,1,'2026-01-18 14:37:19','2026-01-18 14:37:19'),(16,'教练列表','coach:list','menu',5,'/coach/list',NULL,NULL,1,1,'2026-01-18 14:37:19','2026-01-18 14:37:19'),(17,'教练申请','coach:application','menu',5,'/coach/application',NULL,NULL,2,1,'2026-01-18 14:37:19','2026-01-18 14:37:19');
/*!40000 ALTER TABLE `sys_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role`
--

DROP TABLE IF EXISTS `sys_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '角色名称',
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '角色编码',
  `sort` int DEFAULT NULL COMMENT '排序',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role`
--

LOCK TABLES `sys_role` WRITE;
/*!40000 ALTER TABLE `sys_role` DISABLE KEYS */;
INSERT INTO `sys_role` VALUES (1,'超级管理员','admin',1,1,'拥有所有权限','2026-01-18 14:37:19','2026-01-18 14:37:19',0,NULL);
/*!40000 ALTER TABLE `sys_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_permission`
--

DROP TABLE IF EXISTS `sys_role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role_permission` (
  `role_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `sys_role_permission_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `sys_role` (`id`),
  CONSTRAINT `sys_role_permission_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `sys_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_permission`
--

LOCK TABLES `sys_role_permission` WRITE;
/*!40000 ALTER TABLE `sys_role_permission` DISABLE KEYS */;
INSERT INTO `sys_role_permission` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17);
/*!40000 ALTER TABLE `sys_role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user`
--

DROP TABLE IF EXISTS `sys_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户名',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '密码',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '姓名',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邮箱',
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '头像',
  `department_id` int DEFAULT NULL COMMENT '部门ID',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `department_id` (`department_id`),
  CONSTRAINT `sys_user_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `sys_department` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user`
--

LOCK TABLES `sys_user` WRITE;
/*!40000 ALTER TABLE `sys_user` DISABLE KEYS */;
INSERT INTO `sys_user` VALUES (1,'admin','$2b$12$pwre9acCVbDcdx9/cZHhL.fiWXUMOCBav5XloAsZ1sXgPXibPWE46','超级管理员',NULL,NULL,NULL,1,1,NULL,'2026-01-18 14:39:53','2026-01-18 14:39:53',0,NULL);
/*!40000 ALTER TABLE `sys_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user_role`
--

DROP TABLE IF EXISTS `sys_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_role` (
  `user_id` int NOT NULL,
  `role_id` int NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `sys_user_role_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`),
  CONSTRAINT `sys_user_role_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `sys_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user_role`
--

LOCK TABLES `sys_user_role` WRITE;
/*!40000 ALTER TABLE `sys_user_role` DISABLE KEYS */;
INSERT INTO `sys_user_role` VALUES (1,1);
/*!40000 ALTER TABLE `sys_user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creator_id` int NOT NULL COMMENT '发起人ID',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '组队标题',
  `sport_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '运动类型：golf/pickleball/tennis/squash',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '组队描述',
  `activity_date` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '活动日期 YYYY-MM-DD',
  `activity_time` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '活动时间 HH:MM',
  `location` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '活动地点',
  `venue_id` int DEFAULT NULL COMMENT '关联场馆ID',
  `max_members` int DEFAULT NULL COMMENT '最大人数',
  `current_members` int DEFAULT NULL COMMENT '当前人数',
  `fee_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '费用类型：free免费/AA均摊/fixed固定',
  `fee_amount` int DEFAULT NULL COMMENT '费用金额（金币）',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态：recruiting招募中/full已满员/completed已完成/cancelled已取消',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  KEY `creator_id` (`creator_id`),
  CONSTRAINT `team_ibfk_1` FOREIGN KEY (`creator_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_member`
--

DROP TABLE IF EXISTS `team_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_member` (
  `id` int NOT NULL AUTO_INCREMENT,
  `team_id` int NOT NULL COMMENT '组队ID',
  `member_id` int NOT NULL COMMENT '成员ID',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态：joined已加入/quit已退出',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `team_id` (`team_id`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `team_member_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`),
  CONSTRAINT `team_member_ibfk_2` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_member`
--

LOCK TABLES `team_member` WRITE;
/*!40000 ALTER TABLE `team_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ui_icon`
--

DROP TABLE IF EXISTS `ui_icon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ui_icon` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图标编码，如 tabbar-home',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图标名称，如 首页图标',
  `app_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '应用类型：user/coach',
  `category` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分类：tabbar/menu/function/other',
  `icon_normal` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '普通状态图标URL',
  `icon_active` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '选中状态图标URL',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '使用说明',
  `sort_order` int DEFAULT NULL COMMENT '排序',
  `is_active` tinyint(1) DEFAULT NULL COMMENT '是否启用',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ui_icon`
--

LOCK TABLES `ui_icon` WRITE;
/*!40000 ALTER TABLE `ui_icon` DISABLE KEYS */;
/*!40000 ALTER TABLE `ui_icon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ui_image`
--

DROP TABLE IF EXISTS `ui_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ui_image` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图片编码，如 empty-state',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图片名称',
  `app_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '应用类型：user/coach/admin',
  `category` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分类：background/empty/icon/logo/other',
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图片URL',
  `suggested_width` int DEFAULT NULL COMMENT '建议宽度(px)',
  `suggested_height` int DEFAULT NULL COMMENT '建议高度(px)',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '使用说明',
  `sort_order` int DEFAULT NULL COMMENT '排序',
  `is_active` tinyint(1) DEFAULT NULL COMMENT '是否启用',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ui_image`
--

LOCK TABLES `ui_image` WRITE;
/*!40000 ALTER TABLE `ui_image` DISABLE KEYS */;
/*!40000 ALTER TABLE `ui_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ui_theme`
--

DROP TABLE IF EXISTS `ui_theme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ui_theme` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '主题编码，如 wimbledon',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '主题名称，如 温网风格',
  `app_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '应用类型：user/coach/admin',
  `colors` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '颜色配置JSON',
  `preview_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '主题预览图URL',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '主题说明',
  `is_current` tinyint(1) DEFAULT NULL COMMENT '是否当前主题',
  `is_active` tinyint(1) DEFAULT NULL COMMENT '是否启用',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ui_theme`
--

LOCK TABLES `ui_theme` WRITE;
/*!40000 ALTER TABLE `ui_theme` DISABLE KEYS */;
/*!40000 ALTER TABLE `ui_theme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venue`
--

DROP TABLE IF EXISTS `venue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `venue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '场馆名称',
  `type_id` int NOT NULL COMMENT '场馆类型ID',
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '场馆位置',
  `capacity` int DEFAULT NULL COMMENT '容纳人数',
  `price` decimal(10,2) DEFAULT NULL COMMENT '每小时价格(金币)',
  `images` text COLLATE utf8mb4_unicode_ci COMMENT '场馆图片(JSON)',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '场馆描述',
  `facilities` text COLLATE utf8mb4_unicode_ci COMMENT '设施设备(JSON)',
  `gate_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '关联闸机ID',
  `status` int DEFAULT NULL COMMENT '状态: 0停用 1空闲 2使用中',
  `sort` int DEFAULT NULL COMMENT '排序',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  KEY `type_id` (`type_id`),
  CONSTRAINT `venue_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `venue_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venue`
--

LOCK TABLES `venue` WRITE;
/*!40000 ALTER TABLE `venue` DISABLE KEYS */;
INSERT INTO `venue` VALUES (1,'1号网球场',1,'A区',4,100.00,NULL,NULL,NULL,NULL,1,0,'2026-01-18 14:39:53','2026-01-18 14:39:53',0,NULL),(2,'2号网球场',1,'A区',4,100.00,NULL,NULL,NULL,NULL,1,0,'2026-01-18 14:39:53','2026-01-18 14:39:53',0,NULL),(3,'3号网球场',1,'A区',4,100.00,NULL,NULL,NULL,NULL,1,0,'2026-01-18 14:39:53','2026-01-18 14:39:53',0,NULL),(4,'匹克球场',2,'B区',4,80.00,NULL,NULL,NULL,NULL,1,0,'2026-01-18 14:39:53','2026-01-18 14:39:53',0,NULL),(5,'壁球馆',3,'B区',2,80.00,NULL,NULL,NULL,NULL,1,0,'2026-01-18 14:39:53','2026-01-18 14:39:53',0,NULL),(6,'1号公共打位',4,'C区',1,60.00,NULL,NULL,NULL,NULL,1,0,'2026-01-18 14:39:53','2026-01-18 14:39:53',0,NULL),(7,'2号公共打位',4,'C区',1,60.00,NULL,NULL,NULL,NULL,1,0,'2026-01-18 14:39:53','2026-01-18 14:39:53',0,NULL),(8,'3号公共打位',4,'C区',1,60.00,NULL,NULL,NULL,NULL,1,0,'2026-01-18 14:39:53','2026-01-18 14:39:53',0,NULL),(9,'VIP包厢',5,'C区',6,200.00,NULL,NULL,NULL,NULL,1,0,'2026-01-18 14:39:53','2026-01-18 14:39:53',0,NULL);
/*!40000 ALTER TABLE `venue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venue_type`
--

DROP TABLE IF EXISTS `venue_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `venue_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '类型名称',
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '图标',
  `sort` int DEFAULT NULL COMMENT '排序',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venue_type`
--

LOCK TABLES `venue_type` WRITE;
/*!40000 ALTER TABLE `venue_type` DISABLE KEYS */;
INSERT INTO `venue_type` VALUES (1,'网球场','tennis',1,1,'2026-01-18 14:39:53','2026-01-18 14:39:53'),(2,'匹克球','pickleball',2,1,'2026-01-18 14:39:53','2026-01-18 14:39:53'),(3,'壁球','squash',3,1,'2026-01-18 14:39:53','2026-01-18 14:39:53'),(4,'高尔夫公共打位','golf',4,1,'2026-01-18 14:39:53','2026-01-18 14:39:53'),(5,'高尔夫包厢','golf-vip',5,1,'2026-01-18 14:39:53','2026-01-18 14:39:53');
/*!40000 ALTER TABLE `venue_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-19  0:30:03
